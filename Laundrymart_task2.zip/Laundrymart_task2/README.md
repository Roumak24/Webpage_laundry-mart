# Laundry Mart

This project is a laundry service website created using HTML.

## Features
- Home page
- Laundry services
- Contact information
- Simple and user-friendly design

## Technologies Used
- HTML